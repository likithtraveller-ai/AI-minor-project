# AI Model Face-Off: Comparison Report

A benchmark comparing four AI assistants (**Claude, ChatGPT, Google Gemini, Perplexity**) on the same prompt, scored on accuracy, clarity, reasoning and creativity.

## Summary

**Claude ranked first with an overall score of 4.75 / 5**, followed by Google Gemini (4.00), ChatGPT (3.75) and Perplexity (3.50). Claude also responded fastest (5.25 s) and scored highest or joint-highest on every criterion.

> These results come from a single test question, so they show performance on that task rather than a general verdict. See [Limitations](#limitations-and-next-steps).

## Methodology

- **Test question (Q01, General Knowledge):** "Explain the difference between artificial intelligence and machine learning in simple language."
- **Models tested:** Claude, ChatGPT, Google Gemini, Perplexity
- **Criteria (1 to 5 each):** Accuracy, Clarity, Reasoning, Creativity
- **Overall score:** average of the four criteria scores
- **Also recorded:** response time and a link to each full response
- **Visualisation:** Power BI clustered bar chart of scores by model

## Results

### Score table

| AI Model | Accuracy | Clarity | Reasoning | Creativity | Overall | Response Time |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| Claude | 5 | 5 | 4 | 5 | **4.75** | 5.25 s |
| Google Gemini | 4 | 5 | 3 | 4 | **4.00** | 9.00 s |
| ChatGPT | 4 | 3 | 4 | 4 | **3.75** | 6.25 s |
| Perplexity | 3 | 4 | 3 | 4 | **3.50** | 6.68 s |

*Response times in the dataset (e.g. `00.06.25`) are read as minutes.seconds.hundredths, i.e. 6.25 seconds.*

![Scores by model](images/scores_by_model.png)

### Overall ranking

1. **Claude**: 4.75
2. **Google Gemini**: 4.00
3. **ChatGPT**: 3.75
4. **Perplexity**: 3.50

### Findings by criterion

| Criterion | Best | Lowest | Average |
|---|---|---|:---:|
| Accuracy | Claude (5) | Perplexity (3) | 4.00 |
| Clarity | Claude, Gemini (5) | ChatGPT (3) | 4.25 |
| Reasoning | Claude, ChatGPT (4) | Gemini, Perplexity (3) | 3.50 |
| Creativity | Claude (5) | Others tied at 4 | 4.25 |

- **Accuracy:** Claude was the only model to score 5; Perplexity scored 3.
- **Clarity:** Claude and Gemini explained the topic most clearly; ChatGPT was weakest here.
- **Reasoning:** The weakest criterion overall (3.50 average); no model scored above 4.
- **Creativity:** Claude scored 5 while the other three tied at 4.

### Response speed

| Rank | Model | Time |
|:---:|---|:---:|
| 1 | Claude | 5.25 s |
| 2 | ChatGPT | 6.25 s |
| 3 | Perplexity | 6.68 s |
| 4 | Google Gemini | 9.00 s |

## Model profiles

- **Claude (4.75):** Strongest and most balanced; 5 on accuracy, clarity and creativity, with reasoning (4) the only relative gap. Also the fastest.
- **Google Gemini (4.00):** Excellent clarity (5) and solid accuracy and creativity (4), but weak reasoning (3) and the slowest response.
- **ChatGPT (3.75):** Even profile with 4 on accuracy, reasoning and creativity, held back by clarity (3).
- **Perplexity (3.50):** Lowest overall, with the weakest accuracy (3) and reasoning (3); clarity and creativity (4) were respectable.

## Conclusion

On this question, Claude was the best performer on overall score, accuracy, creativity and speed, and tied for best on clarity and reasoning. Gemini was the most readable runner-up, ChatGPT was consistent but less clear, and Perplexity trailed mainly on accuracy and reasoning.

## Limitations and next steps

- **Sample size:** Only one question (Q01), so each score is a single data point. Add more questions across categories (coding, math, writing, current events) for a reliable comparison.
- **Scoring method:** Whole-number scores from 1 to 5 hide small differences. Use multiple raters or a written rubric to reduce subjectivity.
- **Timing:** A single run varies with load and network; repeat runs for a fairer speed comparison.
- **Tool differences:** Perplexity is built around live web search, so a general-explanation question may not show its main strengths.

## Response links

| Model | Link |
|---|---|
| ChatGPT | https://chatgpt.com/s/t_6acf66540b34819196fc0bc0de1f0088 |
| Google Gemini | https://share.gemini.google/2Gw5a9DtLlmn |
| Claude | https://claude.ai/chat/969106d1-afca-4cd9-968f-840bfbd1f001 |
| Perplexity | https://www.perplexity.ai/search/733fa5fa-99fa-4563-b0a0-c48a8ee49732 |

## Repository contents

```
ai-model-face-off/
├── README.md                  # this report
├── images/
│   └── scores_by_model.png    # score chart
└── data/
    ├── AI_Model_Face-Off_Benchmark_Dataset.xlsx
    └── power_bi_chart.pdf
```
